package com.example.firebaseauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirebaseauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
