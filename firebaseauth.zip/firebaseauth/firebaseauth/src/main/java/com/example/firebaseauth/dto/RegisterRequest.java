package com.example.firebaseauth.dto;

public class RegisterRequest {
    public String email;
    public String password;
    public String type;
}