package com.example.firebaseauth.dto;

public class LoginRequest {
    public String email;
    public String password;
}
