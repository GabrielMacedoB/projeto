package com.example.firebaseauth.service;

import com.example.firebaseauth.dto.LoginRequest;
import com.example.firebaseauth.dto.RegisterRequest;
import com.google.firebase.auth.*;
import com.google.firebase.auth.UserRecord.CreateRequest; // <-- ESSA LINHA RESOLVE O ERRO DE COMPILAÇÃO
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class FirebaseService {

    public Map<String, Object> login(LoginRequest req) {
        Map<String, Object> res = new HashMap<>();

        try {
            // AQUI, o Firebase Admin SDK é usado para BUSCAR o usuário pelo email.
            // A AUTENTICAÇÃO da senha deve ser feita pelo SDK do Firebase no Front-end (Web/Mobile),
            // que gera um Token de ID que pode ser verificado no backend.
            UserRecord user = FirebaseAuth.getInstance().getUserByEmail(req.email);

            res.put("uid", user.getUid());
            res.put("email", user.getEmail());
            res.put("status", "ok");
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Usuário ou e-mail não encontrado: " + e.getMessage());
        }

        return res;
    }

    public Map<String, Object> register(RegisterRequest req) {
        Map<String, Object> res = new HashMap<>();

        try {
            // O uso de UserRecord.CreateRequest está corrigido com o import acima.
            CreateRequest cr = new CreateRequest()
                    .setEmail(req.email)
                    .setPassword(req.password);

            UserRecord user = FirebaseAuth.getInstance().createUser(cr);

            // Se você precisar adicionar dados personalizados (como o 'type') ao usuário:
            Map<String, Object> claims = new HashMap<>();
            claims.put("userType", req.type);
            FirebaseAuth.getInstance().setCustomUserClaims(user.getUid(), claims);

            res.put("uid", user.getUid());
            res.put("email", user.getEmail());
            res.put("type", req.type);
            res.put("status", "created");
        } catch (FirebaseAuthException e) {
            res.put("status", "error");
            // Tratamento comum para erros como 'email já em uso' ou 'senha fraca'.
            res.put("message", "Erro ao registrar: " + e.getMessage());
        }

        return res;
    }
}