package com.example.firebaseauth.controller;

import com.mercadopago.MercadoPagoConfig;
import com.mercadopago.client.preference.PreferenceClient;
import com.mercadopago.client.preference.PreferenceItemRequest;
import com.mercadopago.client.preference.PreferenceRequest;
import com.mercadopago.resources.preference.Preference;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/pagamento")
public class PagamentoController {

    @GetMapping("/criar")
    public String criarPreferencia(@RequestParam("tipo") String tipoPlano) {
        // SUAS CREDENCIAIS
        MercadoPagoConfig.setAccessToken("APP_USR-6483963218595129-112517-07714b2ad56a838947b7cc4a572ba86e-3016024623");

        try {
            BigDecimal preco;
            String titulo;

            // Define o preço baseado no plano escolhido
            switch (tipoPlano) {
                case "basico":
                    preco = new BigDecimal("19.90");
                    titulo = "Plano Básico - Sabiá";
                    break;
                case "pro":
                    preco = new BigDecimal("39.90");
                    titulo = "Plano Profissional - Sabiá";
                    break;
                case "empresa":
                    preco = new BigDecimal("79.90");
                    titulo = "Plano Empresarial - Sabiá";
                    break;
                default:
                    return "erro: plano invalido";
            }

            // Cria o item com o preço correto
            PreferenceItemRequest itemRequest = PreferenceItemRequest.builder()
                    .title(titulo)
                    .quantity(1)
                    .unitPrice(preco)
                    .currencyId("BRL")
                    .build();

            List<PreferenceItemRequest> items = new ArrayList<>();
            items.add(itemRequest);

            PreferenceRequest preferenceRequest = PreferenceRequest.builder()
                    .items(items)
                    .build();

            PreferenceClient client = new PreferenceClient();
            Preference preference = client.create(preferenceRequest);

            return preference.getId();

        } catch (Exception e) {
            e.printStackTrace();
            return "erro";
        }
    }
}