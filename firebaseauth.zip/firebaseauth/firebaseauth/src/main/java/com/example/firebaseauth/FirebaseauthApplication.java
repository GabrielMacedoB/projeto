package com.example.firebaseauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirebaseauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirebaseauthApplication.class, args);
	}

}
